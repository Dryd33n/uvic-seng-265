cat tests/in01.txt | ./survey | diff tests/out01.txt -
cat tests/in02.txt | ./survey | diff tests/out02.txt -
cat tests/in03.txt | ./survey | diff tests/out03.txt -
cat tests/in04.txt | ./survey | diff tests/out04.txt -
