#ifndef _OUTPUT_H_
#define _OUTPUT_H_

/* add your include and prototypes here*/
void printIntro(const int numRespondents);


#endif
