#ifndef _OUTPUT_H_
#define _OUTPUT_H_

/* add your include and prototypes here*/
void printIntro(int numRespondents);
void printQuestionsWithRPF(float** rpfArr, Survey survey);
void printResponseCatScores(float** catScores, int numRespondents);
void printAvgCatScores(float * avgCatScores);


#endif
