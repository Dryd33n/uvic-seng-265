cat tests/in01.txt | ./dyn_survey | diff tests/out01.txt -
cat tests/in02.txt | ./dyn_survey | diff tests/out02.txt -
cat tests/in03.txt | ./dyn_survey | diff tests/out03.txt -
cat tests/in04.txt | ./dyn_survey | diff tests/out04.txt -
cat tests/in05.txt | ./dyn_survey | diff tests/out05.txt -
cat tests/in06.txt | ./dyn_survey | diff tests/out06.txt -
