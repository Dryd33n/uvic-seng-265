class InvalidLogoutException(Exception):
	''' Invalid Logout '''