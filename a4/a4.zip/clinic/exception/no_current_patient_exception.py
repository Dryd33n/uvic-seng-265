class NoCurrentPatientException(Exception):
	''' No Current Patient '''