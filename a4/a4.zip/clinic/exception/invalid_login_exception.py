class InvalidLoginException(Exception):
	''' Invalid Login '''