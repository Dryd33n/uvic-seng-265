class IllegalAccessException(Exception):
	''' Illegal Access '''