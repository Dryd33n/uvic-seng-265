class DuplicateLoginException(Exception):
	''' Invalid Login '''