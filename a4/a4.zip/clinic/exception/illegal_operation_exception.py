class IllegalOperationException(Exception):
	''' Illegal Operation '''