
class Controller:
    def logout(self):
        pass

    def login(self, param, param1):
        pass

    def is_logged(self):
        pass

    def create_patient(self, param, param1, param2, param3, param4, param5):
        pass

    def create_note(self, param):
        pass

    def set_current_patient(self, param):
        pass

    def search_note(self, param):
        pass

    def retrieve_notes(self, param):
        pass

    def delete_note(self, param):
        pass

    def list_notes(self):
        pass

    def update_note(self, param, param1):
        pass

    def get_current_patient(self):
        pass

    def list_patients(self):
        pass

    def delete_patient(self, param):
        pass

    def search_patient(self, param):
        pass

    def update_patient(self, param, param1, param2, param3, param4, param5, param6):
        pass

    def retrieve_patients(self, param):
        pass