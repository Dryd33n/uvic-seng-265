
class PatientRecord:
    def __init__(self):
        self.autoCounter = 0
        self.records = []

    def